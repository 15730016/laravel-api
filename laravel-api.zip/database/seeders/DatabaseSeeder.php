<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Category;
use App\Models\Brand;
use App\Models\Product;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Create admin user
        User::create([
            'name' => 'Admin',
            'email' => 'admin@example.com',
            'password' => Hash::make('password'),
            'is_admin' => true,
        ]);

        // Create demo categories
        $categories = [
            ['name' => 'Điện thoại', 'slug' => 'dien-thoai'],
            ['name' => 'Laptop', 'slug' => 'laptop'],
            ['name' => 'Máy tính bảng', 'slug' => 'may-tinh-bang'],
            ['name' => 'Phụ kiện', 'slug' => 'phu-kien'],
        ];

        foreach ($categories as $category) {
            Category::create($category);
        }

        // Create demo brands
        $brands = [
            ['name' => 'Apple', 'slug' => 'apple'],
            ['name' => 'Samsung', 'slug' => 'samsung'],
            ['name' => 'Xiaomi', 'slug' => 'xiaomi'],
            ['name' => 'Dell', 'slug' => 'dell'],
        ];

        foreach ($brands as $brand) {
            Brand::create($brand);
        }

        // Create demo products
        $products = [
            [
                'name' => 'iPhone 15 Pro Max',
                'slug' => 'iphone-15-pro-max',
                'description' => 'iPhone 15 Pro Max mới nhất từ Apple',
                'price' => 34990000,
                'stock' => 100,
                'category_id' => 1,
                'brand_id' => 1,
                'images' => json_encode(['https://images.pexels.com/photos/462118/pexels-photo-462118.jpeg']),
            ],
            [
                'name' => 'Samsung Galaxy S24 Ultra',
                'slug' => 'samsung-galaxy-s24-ultra',
                'description' => 'Samsung Galaxy S24 Ultra với công nghệ mới nhất',
                'price' => 29990000,
                'stock' => 150,
                'category_id' => 1,
                'brand_id' => 2,
                'images' => json_encode(['https://images.pexels.com/photos/462118/pexels-photo-462118.jpeg']),
            ],
            [
                'name' => 'MacBook Pro 16"',
                'slug' => 'macbook-pro-16',
                'description' => 'MacBook Pro 16" với chip M3 Max',
                'price' => 69990000,
                'stock' => 50,
                'category_id' => 2,
                'brand_id' => 1,
                'images' => json_encode(['https://images.pexels.com/photos/462118/pexels-photo-462118.jpeg']),
            ],
        ];

        foreach ($products as $product) {
            Product::create($product);
        }
    }
}
