<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\BrandController;
use App\Http\Controllers\BannerController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\VoucherController;
use App\Http\Controllers\FlashSaleController;
use App\Http\Controllers\PaymentController;

// Public routes
Route::get('products', [ProductController::class, 'index']);
Route::get('products/{id}', [ProductController::class, 'show']);
Route::get('categories', [CategoryController::class, 'index']);
Route::get('categories/{id}', [CategoryController::class, 'show']);
Route::get('brands', [BrandController::class, 'index']);
Route::get('brands/{id}', [BrandController::class, 'show']);
Route::get('banners', [BannerController::class, 'index']);
Route::get('posts', [PostController::class, 'index']);
Route::get('posts/{id}', [PostController::class, 'show']);
Route::get('flash-sales', [FlashSaleController::class, 'index']);
Route::get('flash-sales/{id}', [FlashSaleController::class, 'show']);

// Guest checkout routes
Route::post('orders/guest', [OrderController::class, 'guestCheckout']);
Route::get('orders/guest/{orderNumber}', [OrderController::class, 'guestOrderStatus']);

// Protected routes (requires authentication)
Route::middleware('auth:sanctum')->group(function () {
    // Reviews
    Route::post('reviews', [ReviewController::class, 'store']);
    Route::put('reviews/{id}', [ReviewController::class, 'update']);
    Route::delete('reviews/{id}', [ReviewController::class, 'destroy']);
    
    // Orders
    Route::get('orders', [OrderController::class, 'index']);
    Route::post('orders', [OrderController::class, 'store']);
    Route::get('orders/{id}', [OrderController::class, 'show']);
    
    // Vouchers
    Route::post('vouchers/validate', [VoucherController::class, 'validateVoucher']);
    
    // Payment
    Route::post('payment/vnpay', [PaymentController::class, 'createVnPayPayment']);
    Route::post('payment/vnpay/callback', [PaymentController::class, 'vnPayCallback']);
});

// Admin routes
Route::middleware(['auth:sanctum', 'admin'])->prefix('admin')->group(function () {
    // Products management
    Route::post('products', [ProductController::class, 'store']);
    Route::put('products/{id}', [ProductController::class, 'update']);
    Route::delete('products/{id}', [ProductController::class, 'destroy']);
    
    // Categories management
    Route::post('categories', [CategoryController::class, 'store']);
    Route::put('categories/{id}', [CategoryController::class, 'update']);
    Route::delete('categories/{id}', [CategoryController::class, 'destroy']);
    
    // Brands management
    Route::post('brands', [BrandController::class, 'store']);
    Route::put('brands/{id}', [BrandController::class, 'update']);
    Route::delete('brands/{id}', [BrandController::class, 'destroy']);
    
    // Banners management
    Route::post('banners', [BannerController::class, 'store']);
    Route::put('banners/{id}', [BannerController::class, 'update']);
    Route::delete('banners/{id}', [BannerController::class, 'destroy']);
    
    // Posts management
    Route::post('posts', [PostController::class, 'store']);
    Route::put('posts/{id}', [PostController::class, 'update']);
    Route::delete('posts/{id}', [PostController::class, 'destroy']);
    
    // Reviews management
    Route::get('reviews', [ReviewController::class, 'adminIndex']);
    Route::post('reviews/{id}/approve', [ReviewController::class, 'approve']);
    
    // Orders management
    Route::get('orders', [OrderController::class, 'adminIndex']);
    Route::put('orders/{id}/status', [OrderController::class, 'updateStatus']);
    
    // Vouchers management
    Route::resource('vouchers', VoucherController::class);
    
    // Flash sales management
    Route::resource('flash-sales', FlashSaleController::class);
});
